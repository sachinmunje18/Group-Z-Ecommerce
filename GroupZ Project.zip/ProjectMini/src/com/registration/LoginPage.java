package com.registration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class LoginPage {



	public static void main(String[] args) throws SQLException {
		
		
	try(	Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","Account@name18");
			
			PreparedStatement ps=connection.prepareStatement(" insert into registrationForm(Email,password) values (?, ?)");
			
			
			
			Scanner sc= new Scanner(System.in);){
		
		System.out.println("Enter userName(Email)");
		String userName = sc.next();
		
		System.out.println("Enter password- *****");
		String password = sc.next();
		
		
		
		if(userName.equals(userName)&& password.equals(password)) {
			
			System.out.println("Login Successfully...");
		}
		else
		{
			System.out.println("Invalid username or password...");
		}
		
		
	}

	}

}
