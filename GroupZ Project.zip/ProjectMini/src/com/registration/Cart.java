package com.registration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Cart {

	public void setVisible2(boolean b) {

		int productId;
		
	 
	     Scanner sc=new Scanner(System.in);
	     System.out.println("Enter productId to add product to cart");
	     
	      productId= sc.nextInt();
	      
	      System.out.println(productId);  
	    
	      
	      Connection con = null;
	      PreparedStatement p = null;
	      ResultSet rs = null;
	      
	      try {
	     	 Connection connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","Account@name18");
	     	 PreparedStatement ps=connection.prepareStatement(" insert into products( productName, Price) values(?,?)");
	          
	          String sql = "select *from products where productID=? "; 
	          PreparedStatement ps1=connection.prepareStatement(sql);
	      
	          
	          ps1.setInt(1, productId);
	          rs = ps1.executeQuery();

	    
	          System.out.println("id   \t productName    \t Price  ");
	
	          while (rs.next()) {

	              int productId1 = rs.getInt("productId");
	              
	              String productName1 = rs.getString("productName");
	              
	            String Price1 = rs.getString("price");
	           
	              System.out.println(productId1 + "\t" + productName1
	                                 + "\t" +"\t"+ Price1+"\n");
	              

		  	  		Connection connection8=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","Account@name18");
		  	  		PreparedStatement ps8=connection8.prepareStatement(" insert into orders(productId,productNAME,PRICE) values(?,?,?)");
		  	  		ps8.setInt(1, productId);
		  	  		ps8.setString(2, productName1);
		  	  		ps8.setString(3, Price1);
		  	  	
		  	  	ps8.executeUpdate();
				System.out.println("Product added into cart Successfully...");
				
				

				String query="select sum(PRICE) from orders;";
		
		     	try {
		     		 Connection connection9 =DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","Account@name18");
		     		Statement st=connection9.createStatement();

					ResultSet set=st.executeQuery(query);
					
				
					 String Countrun="";
				      while(set.next()){
				      Countrun = set.getString(1);
				      System.out.println("Total Cart price :" +Countrun);
				       } 
					
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	         
		
		     	 
		     	 System.out.println("Procced to buy.....");
		     	 
	              
	          }      
	      
	      }
	          catch (SQLException e) {

	              System.out.println(e);
	 
	           }
}
	
	public static void main(String[] args) {
			
		}
	    
 }
		
	
	



