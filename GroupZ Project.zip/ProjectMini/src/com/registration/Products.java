package com.registration;


//Java Program retrieving contents of
//Table Using JDBC connection

//Java code producing output which is based
//on values stored inside the "cuslogin" table in DB

//Importing SQL libraries to create database
import java.sql.*;
import java.util.Scanner;

public class Products {	
	
	public void setVisible(boolean b) {
	// TODO Auto-generated method stub
	


	
	

 // Step1: Main driver method
   // Step 2: Making connection using
     // Connection type and inbuilt function on
     Connection con = null;
     PreparedStatement p = null;
     ResultSet rs = null;

    // con = connection.connectDB();

     // Try block to catch exception/s
     try {
    	 Connection connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","Account@name18");
    	 PreparedStatement ps=connection.prepareStatement(" insert into products( productName, price,  productDescription, quantity) values(?,?,?,?)");
         // SQL command data stored in String datatype
         String sql = "select * from products";
         ps = connection.prepareStatement(sql);
         rs = ps.executeQuery();

         // Printing productId, ProductName, ProductDescription,price, Quantity
         // of the SQL command above
         System.out.println("id  \tt name  \t price     \t\t description      \t\t quantity \n");

         // Condition check
         while (rs.next()) {

             int productId = rs.getInt("productId");
             String productName = rs.getString("productName");
             String price = rs.getString("price");
             String productDescription= rs.getString("productDescription");
             int quantity =rs.getInt("quantity");
             System.out.println(productId + "\t\t" + productName
                                + "\t\t" + price+"\t\t"+productDescription+"\t\t"+quantity+"\n");
         }
     }

     // Catch block to handle exception
     catch (SQLException e) {

         // Print exception pop-up on screen
         System.out.println(e);
     }
//     int productId;
//     System.out.println("Choose produts to buy.... ");
//     
//     Scanner sc=new Scanner(System.in);
//     System.out.println("Enter your productId");
//      productId= sc.nextInt();
//      
//      System.out.println(productId);  
//      
      Cart c=new Cart();
      c.setVisible2(true);
     
 }
	
}