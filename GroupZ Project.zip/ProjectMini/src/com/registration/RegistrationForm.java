package com.registration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class RegistrationForm {
	
	public static void insertIntoUser(String FirstName, String LastName, long mobileNumber, String Email, String password  ) throws SQLException {
		
		try {
		
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","Account@name18");
		PreparedStatement ps=connection.prepareStatement(" insert into registrationForm( FirstName, LastName,  MobileNumber, Email,password) values(?,?,?,?,?)");
		ps.setString(1, FirstName);
		ps.setString(2, LastName);
		ps.setLong(3, mobileNumber);
		ps.setString(4, Email);
		ps.setString(5, password);
		
		ps.execute();
		System.out.println("Registration successfully");
		connection.close();
		
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws SQLException {
		System.out.println("Welcom to OnlineShoping ");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your firstName");
		String FirstName =sc.next();
		
		System.out.println("Enter your LastName");
		String LastName= sc.next();
		
		System.out.println("Enter your MobileNumber");
		long MobileNumber= sc.nextLong();
		
		System.out.println("Enter your EmailId");
		String Email=sc.next();
		
		System.out.println("Create your password");
		String password= sc.next();
		
		
		RegistrationForm.insertIntoUser(FirstName, LastName, MobileNumber, Email, password);
		
		System.out.println("enter userName(Email)");
		String userName=sc.next();
		
		System.out.println("Enter password");
		String psw=sc.next();

		String textField = userName ;
		 String passwordField = psw ;
		 
		 try {
			 String userName1=textField;
			 String psw1= passwordField;
			 
			 Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","Account@name18");
			 PreparedStatement ps=connection.prepareStatement("SELECT * FROM registrationForm where Email=? and password=?");
			 ps.setString(1, userName1);
			 ps.setString(2, psw);
			 
			 ResultSet r=ps.executeQuery();
			 
			 if(r.next()) {
		
		
				 System.out.println("successfully loggin");
				 Products ps5 = new Products();
				 ps5.setVisible(true);
			 }
			 else {
				 System.out.println("Incorrect username or password");
			 }
			 
		 }
		catch(Exception e1) {
			e1.printStackTrace();
		}
		
	
		
	}

}
