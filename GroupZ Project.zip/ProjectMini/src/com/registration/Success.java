package com.registration;

public class Success {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
	
		
	}

}
